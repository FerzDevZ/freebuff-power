# W3C Trace Context Propagation

Pass `traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01` across all HTTP and gRPC headers.
