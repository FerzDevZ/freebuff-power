# Gall's Law of Complex Systems

A complex system that works is invariably found to have evolved from a simple system that worked.
